@extends('layouts.master')

@section('title', 'Home Page')

@section('content')
  <h1>Welcome to my site!</h1>
@endsection
