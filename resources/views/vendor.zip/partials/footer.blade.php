<footer>
  <!-- your footer content -->
</footer>
