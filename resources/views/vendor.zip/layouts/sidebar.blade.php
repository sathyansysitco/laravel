<div class="bg-light p-3 h-100">
    <h5>Menu</h5>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="{{ route('dashboard') }}" class="nav-link">Dashboard</a></li>
        <li class="nav-item"><a href="{{ route('posts.index') }}" class="nav-link">Posts</a></li>
        <li class="nav-item"><a href="{{ route('posts.create') }}" class="nav-link">Create Post</a></li>
    </ul>
</div>
